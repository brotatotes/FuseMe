A python module for audio and music processing.


